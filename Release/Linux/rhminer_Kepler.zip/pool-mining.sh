#!/bin/bash
while true
do
    ./rhminer -s somepool.org:1379 -su 529692-23.0.rig -cpu -cputhreads 4 -r 40
    sleep 5s
done




